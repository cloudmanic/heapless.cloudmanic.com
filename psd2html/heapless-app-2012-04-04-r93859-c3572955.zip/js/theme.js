$(function() {
	if($.browser.msie) {
		$('html').addClass('th-ie');
	}
});